import type {VideoProps} from './props';
export const totalSeconds=(_p:VideoProps)=>65.9;
