#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p public/footage/v18ui
ffmpeg -y -i source-footage/avatar-app.webm -vf fps=25 -q:v 2 public/footage/v18ui/%04d.jpg
