import sharp from '/tmp/posture-guard/video/node_modules/sharp/lib/index.js';
const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="640" height="800" viewBox="0 0 640 800">
<rect width="640" height="800" fill="#c4c8cd"/>
<path d="M215 184 C210 55 421 49 429 187 L451 409 Q432 446 406 418 L398 259 L241 259 L237 415 Q204 447 184 410Z" fill="#201816"/>
<path d="M283 309 L282 382 Q319 407 358 382 L356 309" fill="#755039"/>
<path d="M282 364 Q320 392 358 364 Q395 370 451 405 Q490 431 510 514 L547 778 L92 778 L130 514 Q144 433 187 405 Q244 371 282 364Z" fill="#305c96"/>
<path d="M185 405 Q154 440 145 518 L116 735 Q123 759 151 749 L201 526" fill="#3768a4"/>
<path d="M451 405 Q484 440 493 518 L523 735 Q516 759 489 749 L437 526" fill="#3768a4"/>
<path d="M283 365 Q319 394 357 365 L372 380 Q320 424 269 380Z" fill="#24466f"/>
<ellipse cx="229" cy="226" rx="16" ry="29" fill="#79533c"/><ellipse cx="411" cy="226" rx="16" ry="29" fill="#79533c"/>
<ellipse cx="320" cy="218" rx="88" ry="112" fill="#926746"/>
<path d="M230 194 Q215 79 324 92 Q423 94 410 190 Q389 144 376 136 Q328 166 246 166Z" fill="#201816"/>
<path d="M245 192 Q265 181 288 190 M352 190 Q374 181 393 192" fill="none" stroke="#35251e" stroke-width="7" stroke-linecap="round"/>
<g fill="none" stroke="#241f20" stroke-width="6"><ellipse cx="273" cy="217" rx="31" ry="28"/><ellipse cx="367" cy="217" rx="31" ry="28"/><path d="M304 215 Q320 207 336 215 M241 212 L228 207 M398 212 L412 207"/></g>
<ellipse cx="273" cy="218" rx="7" ry="10" fill="#231e1d"/><ellipse cx="367" cy="218" rx="7" ry="10" fill="#231e1d"/><circle cx="270" cy="214" r="2.5" fill="#fafafa"/><circle cx="364" cy="214" r="2.5" fill="#fafafa"/>
<path d="M320 224 L311 257 Q321 266 332 257" fill="none" stroke="#78503a" stroke-width="5" stroke-linecap="round"/>
<path d="M290 281 Q320 298 350 281 Q322 311 290 281Z" fill="#773e3e"/>
</svg>`;
await sharp(Buffer.from(svg)).resize(384,480).extend({top:70,bottom:90,left:48,right:48,background:'#c4c8cd'}).png().toFile('/tmp/avatar-v18-base.png');
