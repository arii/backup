# BackUp: Posture to Die For

Editable Kiroween review video, v18. Main only, 65.9 seconds, 1920 x 1080 output at30fps. Social composition removed.

## Edit and render
Requires Node per package.json and FFmpeg.
1. npm ci
2. npm run restore-footage
3. npm run studio
4. npm run render

Code-based Remotion project, not a drag-and-drop timeline. Edit src/Main.tsx for the sequence, source offsets, overlay words and audio. Edit src/timeline.ts if changing total length. Raw actual-app capture is included instead of thousands of JPEGs; restoration retains its25fps frames in the30fps output. The original camera-input artwork is included as avatar-base.png and its SVG source in scripts/avatar-source.mjs. The generator import path reflects the original editing environment and must be changed to your installed sharp module if reused; the video render does not need this generator.

The avatar animation was generated at30fps, with a smooth tilt from16–18seconds, hold to32seconds, and return by34seconds. It is an illustrated input, not a real-person camera recording. The actual app detector was not changed or forced. Face/ear landmarks remain approximate; no physical-person recovery is claimed. Corrective speech and chime are added in edit and disclosed. They are not a recording of live product audio.

The approved name WAV is preserved unchanged and unused at public/audio/narration/creditV12.wav. SHA256: 89b345867ba12df234609853c74fbf8f90ed9edab30f0a1b705c4bd4c1497c1e.

The rejected slogan is removed from speech and visuals. Kiroween/Frankenstein and Kiro context is restored. Hook configuration is not claimed as proof of execution. See review/scene-description.md for exact output timing and caveats. No production app changes are included.
